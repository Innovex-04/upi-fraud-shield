// ---------------- FORM SUBMISSION WITH BACKEND INTEGRATION ----------------
document.getElementById("transaction-form").addEventListener("submit", async function (e) {
    e.preventDefault();

    const data = {
        upi_id: document.getElementById("upi-id").value,
        amount: Number(document.getElementById("amount").value),
        time: document.getElementById("time").value,
        location: document.getElementById("location").value,
        device: document.getElementById("device").value,
        frequency: Number(document.getElementById("frequency").value)
    };

    try {
        const response = await fetch("http://127.0.0.1:5000/analyze", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });

        if (!response.ok) {
            throw new Error("Failed to analyze transaction");
        }

        const result = await response.json();

        // Update UI with backend response
        document.getElementById("risk-status").textContent = result.risk_status;
        document.getElementById("risk-score").textContent = result.risk_score;
        document.getElementById("reason").textContent = "⚠️ " + result.reasons;
        document.getElementById("result-section").classList.remove("hidden");
    } catch (error) {
        console.error("Error:", error);
        alert("Error connecting to backend. Ensure the Flask server is running.");
    }
});

// ---------------- SIMULATION FUNCTIONS ----------------
function simulate(type) {
    if (type === 'normal') {
        document.getElementById('upi-id').value = 'user@upi';
        document.getElementById('amount').value = 500;
        document.getElementById('time').value = '14:00';
        document.getElementById('location').value = 'Delhi';
        document.getElementById('device').value = 'known';
        document.getElementById('frequency').value = 2;
    } else if (type === 'scam') {
        document.getElementById('upi-id').value = 'scam@fake';
        document.getElementById('amount').value = 15000;
        document.getElementById('time').value = '23:00';
        document.getElementById('location').value = 'Delhi';
        document.getElementById('device').value = 'new';
        document.getElementById('frequency').value = 6;
    } else if (type === 'phishing') {
        document.getElementById('upi-id').value = 'phish@scam';
        document.getElementById('amount').value = 20000;
        document.getElementById('time').value = '01:00';
        document.getElementById('location').value = 'Unknown';
        document.getElementById('device').value = 'new';
        document.getElementById('frequency').value = 10;
    }

    // Auto-trigger form submission after filling
    document.getElementById('transaction-form').dispatchEvent(new Event('submit'));
}

// ---------------- OPTIONAL: DASHBOARD DATA FETCH (For Future Use) ----------------
// Uncomment and integrate into dashboard.html if needed
/*
async function loadDashboard() {
    try {
        const response = await fetch("http://127.0.0.1:5000/transactions");
        const transactions = await response.json();

        // Example: Update stats dynamically
        document.getElementById("total-checked").textContent = transactions.length;
        // Add more logic to calculate fraud/safe counts and populate charts
    } catch (error) {
        console.error("Error loading dashboard:", error);
    }
}

// Call on dashboard page load (add to dashboard.html script tag)
if (window.location.pathname.includes("dashboard.html")) {
    loadDashboard();
}
*/